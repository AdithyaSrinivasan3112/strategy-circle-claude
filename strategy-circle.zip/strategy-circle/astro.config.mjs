import { defineConfig } from 'astro/config';

// https://astro.build/config
export default defineConfig({
  // Update this to the production domain before deploying.
  // Used for canonical URLs, Open Graph tags, and sitemap generation.
  site: 'https://strategycircle.in',
  output: 'static',
  trailingSlash: 'ignore',
  build: {
    inlineStylesheets: 'auto',
  },
});
